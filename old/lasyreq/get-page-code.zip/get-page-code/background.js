
chrome.runtime.onMessage.addListener(function (message) {
  switch (message.command) {
    case "pageHtml":
      console.log(message.html)
      break;
  
    default:
      break;
  }
})

function logHtmlCode(tab)
{
  chrome.tabs.executeScript(tab.id, { file: "send-page-code.js" });
}

chrome.browserAction.onClicked.addListener(logHtmlCode);
